use dim8194;

CREATE TABLE States(
State_ID int NOT NULL UNIQUE,
StateName varchar(50),
Abbreviation char(2),
YearOfStatehood int,
Capital varchar(50),
Capital_Since int,
LandArea decimal(8,3),
IsPopulousCity Boolean,
MunicipalPopulatiion int DEFAULT NULL,
MetroPopulatiion int DEFAULT NULL,
PRIMARY KEY (StateName)
);

CREATE TABLE County(
StateName Varchar(50),
County Varchar(50) NOT NULL,
Population int,
Latitude decimal (15, 12),
Longitude decimal (15, 12),
PRIMARY KEY (StateName, County),
FOREIGN KEY (StateName) references States(StateName)
);

CREATE TABLE Confirmed_Cases(
StateName Varchar(50),
County Varchar(50),
TestDate date,
PositiveCount int,
PRIMARY KEY (StateName, County, TestDate),
Foreign Key (StateName) references States(StateName),
Foreign Key (StateName, County) references County(StateName, County)
);

CREATE TABLE DEATHS(
StateName Varchar(50),
County Varchar(50),
ReportDate date,
DeathCount int,
PRIMARY KEY (StateName, County, ReportDate),
Foreign Key (StateName) references States(StateName),
Foreign Key (StateName, County) references County(StateName, County)
);

CREATE TABLE VACCINATIONS(
StateName Varchar(50),
TotalDistributed int,
TotalAdministered int,
`Distributed per 100K` int,
`Administered per 100K` int,
`People_with 1+ Doses` int,
`People_with_1+ Doses per 100K` int,
`People with 2+ Doses` int,
`People with 2+ Doses per 100K` int,
PRIMARY KEY (StateName),
Foreign Key (StateName) references States(StateName)
);
