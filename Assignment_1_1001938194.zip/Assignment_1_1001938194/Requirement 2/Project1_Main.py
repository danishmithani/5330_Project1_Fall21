#!/usr/bin/env python
# coding: utf-8

# # Fetching and Cleaning Data

# ## 1. State.csv

# In[1]:


# import cx_Oracle
# from cx_Oracle import DatabaseError
# import configparser
import pymysql
import numpy as np
from sqlalchemy import create_engine
import pandas as pd

#Reading File US_State.csv
StateData = pd.read_csv('./US_State.csv',index_col=False)

#Renaming some columns for ease of understanding
StateData.rename(columns = {'StateID': 'State_ID','State':'StateName', 'Abreviation': 'Abbreviation', 'Date of statehood':'YearOfStatehood', 'Capital since':'Capital_Since', 'Land area In Sq Miles':'LandArea', 'Most populous city':'IsPopulousCity', 'Municipal population':'MunicipalPopulatiion', 'Metropolitan population':'MetroPopulatiion'}, inplace = True)

#Converting IsPopulusCity Column to Boolean format
StateData.IsPopulousCity = StateData['IsPopulousCity'].map(dict(Yes=1, No=0))

#Making MunicipalPopulation Column an Integer Format
StateData['MunicipalPopulatiion'] = StateData['MunicipalPopulatiion'].str.replace(',', '').astype(int)

StateData['MetroPopulatiion'] = StateData['MetroPopulatiion'].str.replace(',', '').fillna(-1).astype(int).replace(-1, np.nan)

#Making MetroPopulation Column an Integer Format after temporarily Converting NaN to -1
# StateData['MetroPopulatiion'] = StateData['MetroPopulatiion'].str.replace(',', '').fillna(-1)

# StateData['MetroPopulatiion'] = StateData['MetroPopulatiion'].astype(int)
# StateData['MetroPopulatiion'] = StateData['MetroPopulatiion'].replace(-1,np.nan)

StateData.head()
# print(StateData['MetroPopulatiion'].describe)


# ## 2. County.csv

# In[3]:


#Reading File US_County.csv
CountyData = pd.read_csv('./US_County.csv',index_col=False)

#Renaming some columns for ease of understanding
CountyData.rename(columns={'Province_State':'StateName', 'Lat': 'Latitude','Long':'Longitude'}, inplace=True)

#Removing Rows with 'Unassigned' County, Empty County & Out of State County
CountyData = CountyData[CountyData.County.str.contains('Unassigned')==False]
CountyData = CountyData.dropna(subset=['County'])
CountyData = CountyData[CountyData.County.str.contains('Out of')==False]
CountyData = CountyData[CountyData.StateName.isin(StateData.StateName)]
CountyData.head()


# ## 3. Us_confirmed_cases.csv

# In[17]:


#Reading File Us_confirmed_cases.csv
ConfirmedCasesData = pd.read_csv('./Us_confirmed_cases.csv',header=None, low_memory=False).T
ConfirmedCasesData.columns = ConfirmedCasesData.iloc[0]
ConfirmedCasesData = ConfirmedCasesData[1:]

#Compressing PositiveCount into single column and Turning dates columns into a row value
ConfirmedCasesData = ConfirmedCasesData.melt(id_vars=["Province_State", "County"], var_name="TestDate", value_name="PositiveCount")
ConfirmedCasesData.rename(columns={'Province_State': 'StateName'}, inplace=True)
ConfirmedCasesData['TestDate'] = pd.to_datetime(ConfirmedCasesData.TestDate)

ConfirmedCasesData = ConfirmedCasesData[ConfirmedCasesData.County.isin(CountyData.County)]
ConfirmedCasesData = ConfirmedCasesData[ConfirmedCasesData.StateName.isin(StateData.StateName)]

# ConfirmedCasesData.head()


# ## 4. Us_deaths.csv

# In[6]:


deathsData = pd.read_csv("./Us_deaths.csv", header=None, low_memory=False).T
deathsData.columns = deathsData.iloc[0]
deathsData = deathsData[1:]

#Compressing DeathCounts into single column and Turning dates columns into a row value
deathsData = deathsData.melt(id_vars=["Province_State", "County"], var_name="ReportDate", value_name="DeathCount")
deathsData.rename(columns={'Province_State':'StateName'}, inplace=True)
deathsData['ReportDate'] = pd.to_datetime(deathsData.ReportDate)


deathsData = deathsData[deathsData.County.isin(CountyData.County)]
deathsData = deathsData[deathsData.StateName.isin(StateData.StateName)]

deathsData.head()


# ## 5. Us_Vaccination.csv

# In[25]:


vaccinationData = pd.read_csv(r"./Us_Vaccination.csv")
vaccinationData.rename(columns = {'State/Territory/Federal Entity':'StateName', 'Total Distributed': 'TotalDistributed','Total Administered':'TotalAdministered','People with 1+ Doses': 'People_with 1+ Doses','People with 1+ Doses per 100K':'People_with_1+ Doses per 100K', 'People with 2 Doses':'People with 2+ Doses', 'People with 2 Doses Per 100K':'People with 2+ Doses Per 100K'}, inplace=True)

vaccinationData = vaccinationData[vaccinationData.StateName.isin(StateData.StateName)]

# vaccinationData.shape
vaccinationData.head()


# # Connection to database

# In[5]:


engine = create_engine("mysql+pymysql://{user}:{pw}@acadmysqldb001p.uta.edu/{db}"
                       .format(user="dim8194",
                               pw="!1Aadanyboy3",
                               db="dim8194"))
# vaccinationData.to_sql('VACCINATIONS', con = engine, if_exists = 'append', chunksize = 10000, index=False)

# deathsData.to_sql('DEATHS', con = engine, if_exists = 'append', chunksize = 10000, index=False)

# ConfirmedCasesData.to_sql('Confirmed_Cases', con = engine, if_exists = 'append', chunksize = 10000, index=False)

# CountyData.to_sql('County', con = engine, if_exists = 'append', chunksize = 1000, index=False)

# StateData.to_sql('States', con = engine, if_exists = 'append', chunksize = 1000, index=False)





# # cx_Oracle.init_oracle_client(lib_dir="/Users/LENOVO/Downloads/instantclient_21_3")

# # err = ''
# # i=0
# # print(i)
# # def add_Data_To_Database(data, start):
# #     global i
# #     start=i
# #     try:
# #         con = cx_Oracle.connect('dim8194/Danishmithani97@acaddbprod.uta.edu:1523/pcse1p.data.uta.edu')
# #         cursor = con.cursor()
# #         for index, x in data.iterrows():
# #             if index<start: continue
# #             cursor.execute("INSERT INTO DEATHS(StateName, County, ReportDate, DeathCount) VALUES(:1, :2, :3, :4)", tuple(x))
# #             con.commit()
# #             i=i+1
# #     except DatabaseError as e:
# #         global err
# #         i=i-1
# #         err, = e.args
# #         print("Oracle-Error-Code:", err.code)
# #         print("Oracle-Error-Message:", err.message)

# #     finally:
# #         cursor.close()
# #         con.close()
# #         if err.code == "ORA-01536":
# #             print("re-running the loop for the rest of data")
            
# #             add_Data_To_Database(data, i)
            
# # len(StateData.iterrows())
# # add_Data_To_Database(StateData, i)
# # print(i)


# con = cx_Oracle.connect('dim8194/Danishmithani97@acaddbprod.uta.edu:1523/pcse1p.data.uta.edu')
# cursor = con.cursor()
# try:
    
# #   conn = create_engine('oracle://dim8194:Danishmithani97@acaddbprod.uta.edu:1523/pcse1p')
# #   StateData.to_sql('STATES', con = conn, if_exists = 'append', chunksize = 1000,index=False)

# # #States Data pushed into the database
# #     for i,x in StateData.iterrows():
# #         print(tuple(x))
# #         cursor.execute("INSERT INTO STATES(State_ID, StateName, Abbreviation, YearOfStatehood, Capital, Capital_Since, LandArea, IsPopulousCity, MunicipalPopulatiion, MetroPopulatiion) VALUES(:1, :2, :3, :4, :5, :6, :7, :8, :9, :10)", tuple(x))
# #         con.commit()
# #     print("States Record inserted succesfully")    

# #County Data pushed into the database
# #     for i,x in CountyData.iterrows():
# # #         print(tuple(x))
# #         cursor.execute("INSERT INTO County(StateName, County, Population, Latitude, Longitude) VALUES(:1, :2, :3, :4, :5)", tuple(x))
# #         con.commit()
# #     print("County Record inserted succesfully")

# #Confirmed_cases Data pushed into the database
# #     for i,x in ConfirmedCasesData.iterrows():
# #         cursor.execute("INSERT INTO CONFIRMED_CASES(StateName, County, TestDate, PositiveCount) VALUES(:1, :2, :3, :4)", tuple(x))
# #         con.commit()
# #     print("Confirmed_cases Data inserted succesfully")


# #US_Deaths Data pushed into the database
# #     for i,x in deathsData.iterrows():
# #         cursor.execute("INSERT INTO DEATHS(StateName, County, ReportDate, DeathCount) VALUES(:1, :2, :3, :4)", tuple(x))
# #         con.commit()
# #     print("County Record inserted succesfully")

# # US_Vaccinations Data pushed into the database
#     for i,x in vaccinationData.iterrows():
#         cursor.execute('INSERT INTO VACCINATIONS(StateName, TotalDistributed, TotalAdministered, "Distributed per 100K", "Administered per 100K", "People_with 1+ Doses", "People_with_1+ Doses per 100K", "People with 2+ Doses", "People with 2+ Doses per 100K") VALUES(:1, :2, :3, :4, :5, :6, :7, :8, :9)', tuple(x))
#         con.commit()
#     print("US Vaccinations Records inserted succesfully")


# except DatabaseError as e:
#     err, = e.args
#     print("Oracle-Error-Code:", err.code)
#     print("Oracle-Error-Message:", err.message)
# finally:
#     cursor.close()
#     con.close()
    
    
    
    

    
    
    
    
    
    
    
    
# # try:
# #     engine = create_engine("oracle://{user}:{pw}@acaddbprod.uta.edu/{db}"
# #                        .format(user="dim8194",
# #                                pw="Danishmithani97",
# #                                db="pcse1p.data.uta.edu"))
    
# #     conn = engine.connect()
# #     data = conn.execute("SELECT * FROM States")
# #     Statesdf = pd.DataFrame(data.fetchall())
# #     Statesdf.columns = data.keys()
# #     print(Statesdf.head())
# #     conn.close()

# # except DatabaseError as e:
# #     err, = e.args
# #     print("Error-Code:", err.code)
# #     print("Error-Message:", err.message)


# In[ ]:




