-- name of state with largest in size
SELECT STATENAME from States
WHERE LANDAREA = (
    SELECT MAX(LANDAREA) from States);
    
-- highest to lowest density of positive cases per thousand of population.
SELECT C_Cases.County, C_Cases.StateName, C.Population, C_Cases.TestDate, C_Cases.PositiveCount, ((C_Cases.PositiveCount/C.Population)*1000) as "Density Per 1K"
FROM COUNTY C, Confirmed_Cases C_Cases
WHERE C.County=C_Cases.County AND C.StateName=C_Cases.StateName
ORDER BY 'Density Per 1K' DESC;

-- density of deaths per thousand of population.
SELECT Deaths.County, Deaths.StateName, C.Population, Deaths.ReportDate, Deaths.DeathCount, ((Deaths.DeathCount/C.Population)*1000) as "Density Per 1K"
FROM COUNTY C, Deaths
WHERE C.County=Deaths.County AND C.StateName=Deaths.StateName
ORDER BY 'Density Per 1K' DESC;

-- SELECT StateName, County,PositiveCount,  ROW_NUMBER() OVER (PARTITION BY StateName ORDER BY PositiveCount desc) As "Rank" 
--FROM Confirmed_Cases;

-- top 10 sensitive counties per state from positive case point of view.
Select StateName, County, Pos_Count
FROM (SELECT StateName, County, Pos_Count,  ROW_NUMBER() OVER (PARTITION BY StateName ORDER BY Pos_Count) As Ranks 
    FROM (SELECT StateName, County, SUM(PositiveCount) Pos_Count
        FROM Confirmed_Cases
        GROUP BY StateName, County
        ORDER BY StateName, SUM(PositiveCount) DESC))
WHERE Ranks<11;

-- top 10 sensitive counties per state from number of death point of view.
Select StateName, County, Death_Count
FROM (SELECT StateName, County, Death_Count,  ROW_NUMBER() OVER (PARTITION BY StateName ORDER BY Death_Count) As Ranks 
    FROM (SELECT StateName, County, SUM(DeathCount) Death_Count
        FROM Deaths
        GROUP BY StateName, County
        ORDER BY StateName, SUM(DeathCount) DESC))
WHERE Ranks<11;

-- report to show the progress of vaccinations
-- Part 1
select StateName, "People_with 1+ Doses"
from VACCINATIONS
order by "People_with 1+ Doses";
-- Part 2
select StateName, "People with 2+ Doses"
from VACCINATIONS
order by "People with 2+ Doses";

-- States that have at least 5% population been vaccinated by 1st dose
select s.StateName, Population, "People_with 1+ Doses"  from
(SELECT COUNTY.StateName, SUM(COUNTY.Population) as Population
  FROM COUNTY
  GROUP BY COUNTY.StateName) s JOIN (SELECT * from VACCINATIONS) v 
on s.StateName = v.StateName
where "People_with 1+ Doses">=Population*0.05;

-- State that has largest population yet to be vaccinated, considering 75% of population to be vaccinated to achieve herd immunity.
select A.StateName, Population, "People with 2+ Doses"
FROM (SELECT COUNTY.StateName, SUM(COUNTY.Population) Population
      FROM COUNTY
      GROUP BY COUNTY.StateName) A JOIN (SELECT * from VACCINATIONS) B ON  A.StateName = B.StateName
WHERE "People with 2+ Doses"<=Population*0.75
order by Population DESC
LIMIT 1;




