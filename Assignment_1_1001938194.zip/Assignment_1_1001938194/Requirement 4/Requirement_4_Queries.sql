
INSERT INTO STATES
VALUES (null, 'St_Name', 'SM', 2021, 'St_Cap', 2021, 1000, 1, 500, 500); 

INSERT INTO STATES
VALUES (1, 'St_Name', 'SM', 2021, 'St_Cap', 2021, 1000, 1, 500, 500); 


INSERT INTO DEATHS
VALUES ('St_Name', 'Count_Name', '23-JAN-21', 0); 