Delete 
from STATES
where StateName='Alaska';