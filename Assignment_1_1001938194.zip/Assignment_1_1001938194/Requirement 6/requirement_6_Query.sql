INSERT INTO States
VALUES (200, 'Dummy State1', 'S1', 2021, 'CAP 1', 2021, 1000, 0, 50, 123);

INSERT INTO States
VALUES (201, 'Dummy State2', 'S2', 2021, 'CAP 2', 2021, 2000, 1, 50, 123);

INSERT INTO States
VALUES (202, 'Dummy State3', 'S3', 2021, 'CAP 3', 2021, 3000, 1, 50, 123);